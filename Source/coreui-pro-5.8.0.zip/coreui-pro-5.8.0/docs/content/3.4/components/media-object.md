---
aliases:
  - "/components/bootstrap/media-object/"
  - "/components/media-object/"
---
