---
aliases:
  - "/components/bootstrap/jumbotron/"
  - "/components/jumbotron/"
---
