---
aliases: "/components/masked-input/"
---
