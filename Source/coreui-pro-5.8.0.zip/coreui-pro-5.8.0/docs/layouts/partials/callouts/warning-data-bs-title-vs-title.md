Feel free to use either `title` or `data-coreui-title` in your HTML. When `title` is used, Popper will replace it automatically with `data-coreui-title` when the element is rendered.
